package dev.xellor.meteormcopt.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.commands.RenderPassDescriptor;
import com.mojang.renderpearl.backend.api.RenderPassBackend;
import meteordevelopment.meteorclient.mixininterface.IGpuDevice;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Applies Meteor's active GUI scissor to render passes created by mcopt's Metal encoder. */
@Pseudo
@Mixin(targets = "mcopt.metal.MetalEncoder", remap = false)
public abstract class MetalEncoderMixin {
    @Inject(method = "createRenderPass", at = @At("RETURN"), remap = false)
    private void meteorMcopt$createRenderPass(RenderPassDescriptor descriptor, CallbackInfoReturnable<RenderPassBackend> cir) {
        ((IGpuDevice) RenderSystem.getDevice()).meteor$onCreateRenderPass(cir.getReturnValue());
    }
}
