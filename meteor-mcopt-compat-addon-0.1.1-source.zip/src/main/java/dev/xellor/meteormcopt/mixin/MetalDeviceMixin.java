package dev.xellor.meteormcopt.mixin;

import com.mojang.renderpearl.backend.api.RenderPassBackend;
import meteordevelopment.meteorclient.mixininterface.IGpuDevice;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;

/** Adds Meteor's scissor-state bridge to mcopt's optional Metal device. */
@Pseudo
@Mixin(targets = "mcopt.metal.MetalDevice", remap = false)
public abstract class MetalDeviceMixin implements IGpuDevice {
    @Unique private int meteorMcopt$x, meteorMcopt$y, meteorMcopt$width, meteorMcopt$height;
    @Unique private boolean meteorMcopt$scissorSet;

    @Override
    public void meteor$pushScissor(int x, int y, int width, int height) {
        if (meteorMcopt$scissorSet) throw new IllegalStateException("Currently there can only be one global scissor pushed");

        meteorMcopt$x = x;
        meteorMcopt$y = y;
        meteorMcopt$width = width;
        meteorMcopt$height = height;
        meteorMcopt$scissorSet = true;
    }

    @Override
    public void meteor$popScissor() {
        if (!meteorMcopt$scissorSet) throw new IllegalStateException("No scissor pushed");

        meteorMcopt$scissorSet = false;
    }

    @Deprecated
    @Override
    public void meteor$onCreateRenderPass(RenderPassBackend backend) {
        if (meteorMcopt$scissorSet) {
            backend.enableScissor(meteorMcopt$x, meteorMcopt$y, meteorMcopt$width, meteorMcopt$height);
        }
    }
}
