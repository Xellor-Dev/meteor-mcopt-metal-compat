package dev.xellor.meteormcopt.mixin;

import meteordevelopment.meteorclient.systems.modules.render.Blur;
import com.mojang.blaze3d.systems.RenderSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * mcopt's Metal renderer currently crashes natively when Meteor's Blur module
 * selects its render pipeline. Skip only that module on the Metal backend so
 * the process remains alive and Meteor can explain what happened.
 */
@Mixin(Blur.class)
public abstract class BlurMetalGuardMixin {
    @Unique private static boolean meteorMcopt$blurWarningShown;

    @Inject(method = "onRenderAfterWorld", at = @At("HEAD"), cancellable = true)
    private void meteorMcopt$skipUnsafeMetalBlur(CallbackInfo ci) {
        if (!"Metal".equals(RenderSystem.getDevice().getDeviceInfo().backendName())) return;

        ci.cancel();

        if (!meteorMcopt$blurWarningShown) {
            meteorMcopt$blurWarningShown = true;
            ((Blur) (Object) this).warning("Blur is disabled with (highlight)mcopt Metal(default) to prevent a native renderer crash.");
        }
    }
}
