package dev.xellor.meteormcopt;

import com.mojang.logging.LogUtils;
import meteordevelopment.meteorclient.addons.GithubRepo;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import org.slf4j.Logger;

/** Registers the mixin-only compatibility addon with Meteor. */
public final class MeteorMcoptCompatAddon extends MeteorAddon {
    public static final Logger LOG = LogUtils.getLogger();

    @Override
    public void onInitialize() {
        LOG.info("Meteor mcopt Metal compatibility addon loaded");
    }

    @Override
    public String getPackage() {
        return "dev.xellor.meteormcopt";
    }

    @Override
    public GithubRepo getRepo() {
        return new GithubRepo("Xellor-Dev", "meteor-mcopt-metal-compat");
    }
}
