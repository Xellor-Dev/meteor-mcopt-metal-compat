# Meteor mcopt Metal Compatibility Addon

Experimental Meteor addon for Minecraft 26.3 Fabric on Apple Silicon.

It adds the compatibility Mixins needed for Meteor Client 26.3-15 to use mcopt Metal 0.3.0-alpha.2 without replacing Meteor itself. It bridges `mcopt.metal.MetalDevice` to Meteor's `IGpuDevice` GUI-scissor API and applies the active scissor to Metal render passes.

Version 0.1.1 also protects against the confirmed native Apple Metal crash in Meteor's `Blur` module. When the active renderer is Metal, the addon skips only Meteor Blur and shows one Meteor warning in chat. Blur remains available on non-Metal renderers.

## Install

1. Restore the original `meteor-client-26.3-15.jar`; do **not** use the earlier patched Meteor JAR alongside this addon.
2. Put the official Meteor JAR, mcopt 0.3.0-alpha.2 and `meteor-mcopt-compat-0.1.1.jar` in the same Prism instance `mods` directory. Remove the older 0.1.0 addon JAR if present.
3. Remove `-Dmcopt.metal=false`, if it was added as a crash workaround.
4. Launch and make sure F3 reports `Metal 3 (mcopt)`, then test Meteor's GUI and its text fields.

## Status

This is vibe code. It has a successful Java 25 build but has not been exhaustively tested across mods, Minecraft updates or Apple Silicon models. Back up your instance and worlds; no warranty or compatibility guarantee is provided.

## Build

Run `./gradlew build` with Java 25. The JAR is written to `build/libs`.

## License

GPL-3.0, because the addon uses Meteor's GPL-3.0 API and compatibility interface.
